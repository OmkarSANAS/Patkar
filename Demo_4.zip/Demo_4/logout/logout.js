function logout(){
    firebase.auth().signOut().then(function() {
      // Sign-out successful.
  
      window.location.href="../main.html";
  
    }).catch(function(error) {
      // An error happened.
    });
  }
